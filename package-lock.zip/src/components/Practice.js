import React from 'react'
import styles from './my-style.module.css';
export default function Practice() {

    const styleDiv = {
        backgroundColor: "green",
        height: "300px",
        width: "300px",
        border: "1px solid #ccc",
        margin: "0 auto",
        display: "flex",
        justifyContent: "center",
        alignItems: "center"
    }

    const ChildDiv = {
        height: "50px",
        color: "#fff"
    }

    return (
        <div>
            {/* inline style */}
            <h4 style={{ color: "red", textAlign: "center" }}>This is a sample text.</h4>

            {/* internal css */}
            <div style={styleDiv}>
                <div style={ChildDiv}>this is a div box</div>
            </div>

            {/* External Css */}
            <div className={styles.mydiv}>
                <span className={styles.extChild}>
                    This is sample div for external css
                </span>
            </div>

        </div>
    )
}
