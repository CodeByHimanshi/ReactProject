import React, {useState, useContext} from 'react';
// import {UserContext} from '../Component_1'; 

export default function Component_3() {
  // const user = useContext(UserContext);
  return (
    <>
    {/* <div><strong>This is First Component-3 <span style={{color:"green"}}>{user}</span> </strong></div> */}
    </>
    
  )
}
