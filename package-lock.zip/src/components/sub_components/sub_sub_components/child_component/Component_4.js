import React, {useContext} from 'react';
import {UserContext} from '../../../Component_1'; 

export default function Component_4() {
    const user = useContext(UserContext);

    return (
        <div>
            <strong>This is First Component-4 <span style={{color:"green"}}>{user}</span></strong>
        </div>
    )
}
