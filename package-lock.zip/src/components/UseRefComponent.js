import React, { useState, useEffect, useRef } from 'react';
import styles from './my-style.module.css';

export default function UseRefComponent() {
  const [inputVal, setInputVal] = useState('');
  // With usRef ----------
  const count = useRef(0);

  // Without useRef ------
  // const [count, setCount] = useState(0);

  useEffect(() => {
    // With usRef ----------
    count.current = count.current + 1;

    // Without useRef ------
    // setCount(count + 1);
  });

  const inputElemt = useRef('');

  const changeStyle = () => {
    // Getting the element (Input tag)
    // console.log(inputElemt.current);

    inputElemt.current.style.backgroundColor = "yellow";
    inputElemt.current.style.color = "red";
  }

  {/* Extra----- */}
 
  const [inputValue, setInputValue] = useState("");
  const previousInputValue = useRef("");

  useEffect(() => {
    previousInputValue.current = inputValue;
  }, [inputValue]);

  return (
    <>
      <input type="text" value={inputVal} onChange={(e) => setInputVal(e.target.value)} />
      {/* // With usRef ---------- */}
      <p>Render Count: {count.current}</p> {/* Access the current value of the count ref */}

      {/* without useRef */}
      {/* <p>Render Count: {count}</p>  */}


      {/* Getting an element with the help of current object intead of (document.getElementById('');) */}

      <input type="text" ref={inputElemt} /> <br />
      <button className={`${styles.btn} ${styles.margin}`} onClick={changeStyle}>Change Style</button> <br />

      {/* Extra----- */}

      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <h2>Current Value: {inputValue}</h2>
      <h2>Previous Value: {previousInputValue.current}</h2>
    </>
  );
}
