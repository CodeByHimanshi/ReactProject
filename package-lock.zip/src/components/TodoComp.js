import React from 'react';
import styles from './my-style.module.css';

export default function TodoComp({todos, addTodo}) {
    return (
        <>
            <div className={styles.todoBbox}>
                <h3>My Todos</h3>
                {todos.map((todo, index) => {
                    return <p key={index}>{todo + index}</p>
                })}
                <button className={styles.btn} onClick={addTodo}>Add Todo</button>
            </div>
        </>
    )
}
