import React, { useReducer } from 'react';
import styles from './my-style.module.css';

export default function useReducerComponent() {

  const initialState = 0;

  const reducer = (state, action) => {

    if (action.type === "increment") {
      return state + 1;
    }
    if (action.type === "decrement") {
      return state - 1;
    }

    return state
  }

  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <>
      <p>The count is: {state}</p>

      <button onClick={() => dispatch({ type: "increment" })} className={styles.inc}>Increment</button>
      <button onClick={() => dispatch({ type: "decrement" })} className={styles.dec}>Decrement</button>
    </>
  )
}
