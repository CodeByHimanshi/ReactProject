import React, {useState, createContext} from 'react';
import styles from './my-style.module.css';
// import Component_2 from './sub_components/Component_2';
// import Component_3 from './sub_components/sub_sub_components/Component_3';
import Component_4 from './sub_components/sub_sub_components/child_component/Component_4';

export const UserContext = createContext(); // Create a context

export default function Component_1() {
  const [user, setUser]= useState('"Hello Himanshi"'); 

    return (
        <UserContext.Provider value={user}>
            <div className={styles.mar}>
                <strong>This is First Component-1 <span className={styles.txtGreen}>{user}</span></strong>
            </div>
            {/* <Component_2/>
            <Component_3/> */}
            <Component_4 />
        </UserContext.Provider>
    )
}
