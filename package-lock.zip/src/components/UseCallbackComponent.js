import React, { useState, useCallback } from 'react';
import styles from './my-style.module.css';
import TodoComp from './TodoComp';

export default function UseCallbackComponent() {

    const [count, setCount] = useState(0);
    const countHandler = () => {
        setCount(count + 1);
    }

    const [todos, setTodos] = useState([]);

    const addTodo = useCallback(() => {
        console.log('render');
        setTodos((td) => [...td, "New Todo"]);
    }, [todos]);

    return (
        <>
            <TodoComp todos={todos} addTodo={addTodo} />
            <div>
                <p>Count {count}</p>
                <button className={styles.btn} onClick={countHandler}>Click</button>
            </div>
        </>
    )
}
