import React, { useState, useEffect } from 'react'
import styles from './my-style.module.css';

export default function MyComponent() {

  const [count, setCount] = useState(0);
  const [calculation, setCalculation] = useState(0);

  useEffect(() => {
    document.title = `EffectCount (${count})`;
    console.log("This is useEffect Text.");
  });

  useEffect(() => {
    setCalculation(() => count * 2);
  }, [count]);

  return (
    <div>
      {/* UseEffect */}
      <div  className={styles.useeffect}>
        <h5>The count of useState is {count}</h5>
        <button className={styles.btn} onClick={() => setCount(count + 1)}> Click me</button>
      </div>

      {/* useEffect with Dependencies  */}

      <p>Count: {count}</p>
      <button className={styles.btn} onClick={() => setCount((c) => c + 1)}>Increment</button>
      <p>Calculation: {calculation}</p>
    </div>
  )
}
