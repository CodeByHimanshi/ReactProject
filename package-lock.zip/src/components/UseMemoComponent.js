import React from 'react'

export default function UseMemoComponent() {
  return (
    <div>UseMemoComponent</div>
  )
}
