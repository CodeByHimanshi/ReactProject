import './App.css';
import Practice from './components/Practice';
import MyComponent from './components/MyComponent';
import Component_1 from './components/Component_1';
import UseRefComponent from './components/UseRefComponent';
import UseReducerComponent from './components/UseReducerComponent'
import UseCallbackComponent from './components/UseCallbackComponent';

function App() {
  return (
    <div className="App" >
      <Practice />
      <MyComponent />
      <Component_1 />
      <UseRefComponent />
      <UseReducerComponent />
      <UseCallbackComponent />
    </div>
  );
}

export default App;
